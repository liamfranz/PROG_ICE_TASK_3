import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> elements = new ArrayList<>();

        System.out.println("Enter the number of elements you want to add to the list:");
        int numberOfElements = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        for (int i = 0; i < numberOfElements; i++) {
            System.out.println("Enter element " + (i + 1) + ":");
            String element = scanner.nextLine();
            elements.add(element);
        }

        System.out.println("Original list: " + elements);

        // Shuffle the elements in the ArrayList
        Collections.shuffle(elements);

        System.out.println("Shuffled list: " + elements);
        scanner.close();
    }
}
