import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> elements = new ArrayList<>();

        System.out.println("Enter the number of elements in the list:");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        // Input elements into the ArrayList
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            elements.add(scanner.nextLine());
        }

        // Display the original ArrayList
        System.out.println("Original list: " + elements);

        // Get the start and end indices for the sublist
        System.out.println("Enter the starting index for extraction:");
        int startIndex = scanner.nextInt();
        System.out.println("Enter the ending index for extraction (exclusive):");
        int endIndex = scanner.nextInt();

        // Validate indices
        if (startIndex < 0 || endIndex > n || startIndex >= endIndex) {
            System.out.println("Invalid indices. Please ensure they are within the bounds of the list.");
        } else {
            // Extract the sublist
            ArrayList<String> sublist = new ArrayList<>(elements.subList(startIndex, endIndex));

            // Display the extracted sublist
            System.out.println("Extracted sublist: " + sublist);
        }

        scanner.close();
    }
}
