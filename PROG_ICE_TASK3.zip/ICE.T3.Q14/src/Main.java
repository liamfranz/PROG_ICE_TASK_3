import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> elements = new ArrayList<>();

        // Input for the ArrayList
        System.out.println("Enter the number of elements in the list:");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            elements.add(scanner.nextLine());
        }

        // Display the original ArrayList
        System.out.println("Original list: " + elements);

        // Input indices for swapping
        System.out.println("Enter the index of the first element to swap:");
        int index1 = scanner.nextInt();
        System.out.println("Enter the index of the second element to swap:");
        int index2 = scanner.nextInt();

        // Check for valid indices
        if (index1 < 0 || index1 >= n || index2 < 0 || index2 >= n) {
            System.out.println("Invalid indices. Please ensure they are within the bounds of the list.");
        } else {
            // Swap elements
            String temp = elements.get(index1);
            elements.set(index1, elements.get(index2));
            elements.set(index2, temp);

            // Display the updated ArrayList
            System.out.println("Updated list after swapping: " + elements);
        }

        scanner.close();
    }
}
