import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList to hold the elements
        ArrayList<String> elements = new ArrayList<>();

        System.out.println("Enter elements to add to the list (type 'exit' to finish):");

        // Input loop to add elements to the ArrayList
        while (true) {
            System.out.print("Enter an element: ");
            String element = scanner.nextLine();

            // Check if the user wants to exit
            if (element.equalsIgnoreCase("exit")) {
                break;
            }

            // Insert the element at the first position (index 0)
            elements.add(0, element);
            System.out.println("Element added at the first position: " + element);
        }

        // Close the scanner
        scanner.close();

        // Print out the elements in the ArrayList
        System.out.println("\nList of elements:");
        for (String e : elements) {
            System.out.println(e);
        }
    }
}
