import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList
        ArrayList<String> elements = new ArrayList<>();

        // Input for the ArrayList
        System.out.println("Enter the number of elements you want to add to the list:");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        // Collecting elements based on user input
        if (n > 0) {
            System.out.println("Enter " + n + " elements:");
            for (int i = 0; i < n; i++) {
                elements.add(scanner.nextLine());
            }
        }

        // Check if the ArrayList is empty
        if (elements.isEmpty()) {
            System.out.println("The list is empty.");
        } else {
            System.out.println("The list is not empty. It contains: " + elements);
        }

        scanner.close();
    }
}
