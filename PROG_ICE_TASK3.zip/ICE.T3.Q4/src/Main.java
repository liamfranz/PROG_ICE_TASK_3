import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList to hold the elements
        ArrayList<String> elements = new ArrayList<>();

        System.out.println("Enter elements to add to the list (type 'exit' to finish):");

        // Input loop to add elements to the ArrayList
        while (true) {
            System.out.print("Enter an element: ");
            String element = scanner.nextLine();

            // Check if the user wants to exit
            if (element.equalsIgnoreCase("exit")) {
                break;
            }

            // Add the element to the ArrayList
            elements.add(element);
            System.out.println("Element added: " + element);
        }

        // Prompt the user to retrieve an element at a specific index
        System.out.print("Enter the index of the element you want to retrieve: ");
        int index = scanner.nextInt();

        // Check if the index is valid
        if (index >= 0 && index < elements.size()) {
            // Retrieve and print the element at the specified index
            String retrievedElement = elements.get(index);
            System.out.println("Element at index " + index + ": " + retrievedElement);
        } else {
            System.out.println("Invalid index. Please enter a number between 0 and " + (elements.size() - 1) + ".");
        }

        // Close the scanner
        scanner.close();
    }
}
