import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList
        ArrayList<String> elements = new ArrayList<>();

        // Input for the ArrayList
        System.out.println("Enter the number of elements in the list:");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            elements.add(scanner.nextLine());
        }

        // Display the original ArrayList
        System.out.println("Original list: " + elements);

        // Ask the user if they want to empty the list
        System.out.println("Do you want to empty the list? (yes/no)");
        String response = scanner.nextLine();

        if (response.equalsIgnoreCase("yes")) {
            // Empty the ArrayList
            elements.clear();
            System.out.println("The list has been emptied.");
        } else {
            System.out.println("The list remains unchanged.");
        }

        // Display the final state of the ArrayList
        System.out.println("Final list: " + elements);

        scanner.close();
    }
}
