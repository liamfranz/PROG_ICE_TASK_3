import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Create the first ArrayList to hold the original elements
        ArrayList<String> originalList = new ArrayList<>();

        System.out.println("Enter elements to add to the original list (type 'exit' to finish):");

        // Input loop to add elements to the original ArrayList
        while (true) {
            System.out.print("Enter an element: ");
            String element = scanner.nextLine();

            // Check if the user wants to exit
            if (element.equalsIgnoreCase("exit")) {
                break;
            }

            // Add the element to the original ArrayList
            originalList.add(element);
            System.out.println("Element added: " + element);
        }

        // Create a second ArrayList to hold the copied elements
        ArrayList<String> copiedList = new ArrayList<>(originalList);

        // Print out the copied list of elements
        System.out.println("\nCopied list of elements:");
        for (String e : copiedList) {
            System.out.println(e);
        }

        // Close the scanner
        scanner.close();
    }
}
