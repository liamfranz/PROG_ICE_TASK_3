import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList
        ArrayList<String> elements = new ArrayList<>();

        // Input for the ArrayList
        System.out.println("Enter the number of elements you want to add to the list:");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            elements.add(scanner.nextLine());
        }

        // Display the original ArrayList and its size
        System.out.println("Original list: " + elements);
        System.out.println("Size of the list: " + elements.size());
        System.out.println("Capacity of the list (before increasing): " + getCapacity(elements));

        // Increase the capacity of the ArrayList
        System.out.println("Enter a minimum capacity to increase the ArrayList to:");
        int minCapacity = scanner.nextInt();
        elements.ensureCapacity(minCapacity);

        // Display the modified ArrayList and its new capacity
        System.out.println("List after ensuring capacity: " + elements);
        System.out.println("Size of the list: " + elements.size());
        System.out.println("Capacity of the list (after increasing): " + getCapacity(elements));

        scanner.close();
    }

    // Helper method to get the capacity of the ArrayList
    private static int getCapacity(ArrayList<?> list) {
        try {
            java.lang.reflect.Field field = ArrayList.class.getDeclaredField("elementData");
            field.setAccessible(true);
            return ((Object[]) field.get(list)).length;
        } catch (Exception e) {
            return -1; // In case of any error, return -1
        }
    }
}
