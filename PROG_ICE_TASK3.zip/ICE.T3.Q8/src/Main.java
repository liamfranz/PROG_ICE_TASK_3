import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList to hold the elements
        ArrayList<String> elements = new ArrayList<>();

        System.out.println("Enter elements to add to the list (type 'exit' to finish):");

        // Input loop to add elements to the ArrayList
        while (true) {
            System.out.print("Enter an element: ");
            String element = scanner.nextLine();

            // Check if the user wants to exit
            if (element.equalsIgnoreCase("exit")) {
                break;
            }

            // Add the element to the ArrayList
            elements.add(element);
            System.out.println("Element added: " + element);
        }

        // Sort the ArrayList
        Collections.sort(elements);
        System.out.println("\nSorted list of elements:");

        // Print out the sorted elements
        for (String e : elements) {
            System.out.println(e);
        }

        // Close the scanner
        scanner.close();
    }
}
