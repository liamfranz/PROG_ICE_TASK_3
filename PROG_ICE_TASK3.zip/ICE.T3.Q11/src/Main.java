import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Integer> elements = new ArrayList<>();

        System.out.println("Enter the number of elements in the list:");
        int n = scanner.nextInt();

        // Input elements into the ArrayList
        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            elements.add(scanner.nextInt());
        }

        // Display the original ArrayList
        System.out.println("Original list: " + elements);

        // Reverse the ArrayList
        Collections.reverse(elements);

        // Display the reversed ArrayList
        System.out.println("Reversed list: " + elements);

        scanner.close();
    }
}
