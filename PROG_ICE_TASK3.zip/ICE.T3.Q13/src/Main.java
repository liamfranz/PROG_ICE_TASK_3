import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create two ArrayLists
        ArrayList<String> list1 = new ArrayList<>();
        ArrayList<String> list2 = new ArrayList<>();

        // Input for the first ArrayList
        System.out.println("Enter the number of elements for the first list:");
        int n1 = scanner.nextInt();
        scanner.nextLine();

        System.out.println("Enter " + n1 + " elements for the first list:");
        for (int i = 0; i < n1; i++) {
            list1.add(scanner.nextLine());
        }

        // Input for the second ArrayList
        System.out.println("Enter the number of elements for the second list:");
        int n2 = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.println("Enter " + n2 + " elements for the second list:");
        for (int i = 0; i < n2; i++) {
            list2.add(scanner.nextLine());
        }

        // Display both ArrayLists
        System.out.println("First list: " + list1);
        System.out.println("Second list: " + list2);

        // Compare the two ArrayLists
        if (list1.equals(list2)) {
            System.out.println("The two lists are equal.");
        } else {
            System.out.println("The two lists are not equal.");
            System.out.println("Differences:");

            // Find differences
            System.out.println("Elements in the first list but not in the second:");
            for (String item : list1) {
                if (!list2.contains(item)) {
                    System.out.println(item);
                }
            }

            System.out.println("Elements in the second list but not in the first:");
            for (String item : list2) {
                if (!list1.contains(item)) {
                    System.out.println(item);
                }
            }
        }

        scanner.close();
    }
}
