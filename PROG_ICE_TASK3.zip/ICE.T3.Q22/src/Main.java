import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList
        ArrayList<String> elements = new ArrayList<>();

        // Input for the ArrayList
        System.out.println("Enter the number of elements you want to add to the list:");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.println("Enter " + n + " elements:");
        for (int i = 0; i < n; i++) {
            elements.add(scanner.nextLine());
        }

        // Display elements with their positions
        System.out.println("Elements in the list with their positions:");
        for (int i = 0; i < elements.size(); i++) {
            System.out.println("Position " + i + ": " + elements.get(i));
        }

        scanner.close();
    }
}
