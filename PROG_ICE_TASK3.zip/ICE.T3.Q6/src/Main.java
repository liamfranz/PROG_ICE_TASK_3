import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList to hold the elements
        ArrayList<String> elements = new ArrayList<>();

        System.out.println("Enter elements to add to the list (type 'exit' to finish):");

        // Input loop to add elements to the ArrayList
        while (true) {
            System.out.print("Enter an element: ");
            String element = scanner.nextLine();

            // Check if the user wants to exit
            if (element.equalsIgnoreCase("exit")) {
                break;
            }

            // Add the element to the ArrayList
            elements.add(element);
            System.out.println("Element added: " + element);
        }

        // Check if there are at least three elements to remove the third one
        if (elements.size() >= 3) {
            // Remove the third element (index 2)
            String removedElement = elements.remove(2);
            System.out.println("Removed the third element: " + removedElement);
        } else {
            System.out.println("Not enough elements in the list to remove the third element.");
        }

        // Print out the updated list of elements
        System.out.println("\nUpdated list of elements:");
        for (String e : elements) {
            System.out.println(e);
        }

        // Close the scanner
        scanner.close();
    }
}
