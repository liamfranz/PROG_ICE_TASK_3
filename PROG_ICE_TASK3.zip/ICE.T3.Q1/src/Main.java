import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an ArrayList to hold the colors
        ArrayList<String> colors = new ArrayList<>();

        System.out.println("Enter colors to add to the list (type 'exit' to finish):");

        while (true) {
            // Prompt the user to enter a color
            System.out.print("Enter a color: ");
            String color = scanner.nextLine();


            if (color.equalsIgnoreCase("exit")) {
                break;
            }

            // Add the color to the ArrayList
            colors.add(color);
            System.out.println("Color added: " + color);
        }

        scanner.close();


        System.out.println("\nList of colors:");
        for (String c : colors) {
            System.out.println(c);
        }
    }
}
