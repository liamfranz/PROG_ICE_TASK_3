import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create two ArrayLists
        ArrayList<String> list1 = new ArrayList<>();
        ArrayList<String> list2 = new ArrayList<>();

        // Input for the first ArrayList
        System.out.println("Enter the number of elements for the first list:");
        int n1 = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.println("Enter " + n1 + " elements for the first list:");
        for (int i = 0; i < n1; i++) {
            list1.add(scanner.nextLine());
        }

        // Input for the second ArrayList
        System.out.println("Enter the number of elements for the second list:");
        int n2 = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.println("Enter " + n2 + " elements for the second list:");
        for (int i = 0; i < n2; i++) {
            list2.add(scanner.nextLine());
        }

        // Display both ArrayLists
        System.out.println("First list: " + list1);
        System.out.println("Second list: " + list2);

        // Join the two ArrayLists
        ArrayList<String> joinedList = new ArrayList<>(list1);
        joinedList.addAll(list2);

        // Display the joined ArrayList
        System.out.println("Joined list: " + joinedList);

        scanner.close();
    }
}
